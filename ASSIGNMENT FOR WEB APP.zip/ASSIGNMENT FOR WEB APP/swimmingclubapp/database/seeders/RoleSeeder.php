<?php

namespace Database\Seeders;

use App\Helpers\Roles;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $superadmin = Role::create(['name' => 'super_admin']);
        $admin = Role::create(['name' => 'admin']);
        $adultswimmer = Role::create(['name' => 'adult_swimmer']);
        $nonadultswimmer = Role::create(['name' => 'non_adult_swimmer']);
        $parent = Role::create(['name' => 'parent']);
        $coach = Role::create(['name' => 'coach']);

        $permission7 = Permission::create(['name' => 'investigate_and_compare_indivudual_peformance_data']);

        //coaches permissions
        $permission1 = Permission::create(['name' => 'view_squad_data']);
        $permission2 = Permission::create(['name' => 'edit_squad_data']);
        $permission3 = Permission::create(['name' => 'edit_squad_training_performance_data']);
        $permission4 = Permission::create(['name' => 'view_squad_training_performance_data']);

        $coach->givePermissionTo([$permission1, $permission2, $permission3, $permission4, $permission7]);

        //adult swimmers and parent of swimmers
        $permission5 = Permission::create(['name' => 'maintain_personal_data']);
        $permission6 = Permission::create(['name' => 'maintain_child_data']);

        $adultswimmer->givePermissionTo([$permission5, $permission6, $permission7]);
        $parent->givePermissionTo([$permission5, $permission6, $permission7]);

        //non adult swimmer

        //club admin
        $permission8 = Permission::create(['name' => 'validate_race_data']);
        $permission9 = Permission::create(['name' => 'edit_race_data']);

        $admin->givePermissionTo([$permission8, $permission9, $permission7]);

        //club super admin
        $permission10 = Permission::create(['name' => 'add_admin']);

        $superadmin->givePermissionTo([$permission8, $permission9, $permission10, $permission7]);
    }
}
