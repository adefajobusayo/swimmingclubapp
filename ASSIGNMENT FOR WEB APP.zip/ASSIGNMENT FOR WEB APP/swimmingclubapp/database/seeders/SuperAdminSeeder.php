<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use App\Helpers\Roles;
use Spatie\Permission\Models\Permission;
use App\Models\User;

class SuperAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'username' => 'SuperAdmin',
            'firstname' => 'Super',
            'lastname' => 'Admin',
            'address' => 'United Kingdom',
            'postal_code' => 100134,
            'phone' => '07037796307',
            'email' => 'superadmin@swimmingclubapp.com',
            'email_verified_at' => now(),
            'date_of_birth' => strtotime(date('Y-m-d')),
            'password' => bcrypt('password'),
            'gender' => 'male',
        ]);

        $user->assignRole('super_admin');


        $user1 = User::create([
            'username' => 'Admin',
            'firstname' => 'Admin',
            'lastname' => 'Admin',
            'address' => 'United Kingdom',
            'postal_code' => 100134,
            'phone' => '07037796307',
            'email' => 'admin@swimmingclubapp.com',
            'email_verified_at' => now(),
            'date_of_birth' => strtotime(date('Y-m-d')),
            'password' => bcrypt('password'),
            'gender' => 'male',
        ]);

        $user1->assignRole('admin');


        $user2 = User::create([
            'username' => 'Coach',
            'firstname' => 'Coach',
            'lastname' => 'Coach',
            'address' => 'United Kingdom',
            'postal_code' => 100134,
            'phone' => '07037796307',
            'email' => 'coach@swimmingclubapp.com',
            'email_verified_at' => now(),
            'date_of_birth' => strtotime(date('Y-m-d')),
            'password' => bcrypt('password'),
            'gender' => 'male',
        ]);

        $user2->assignRole('coach');


        $user3 = User::create([
            'username' => 'Adult',
            'firstname' => 'Adult',
            'lastname' => 'Swimmer',
            'address' => 'United Kingdom',
            'postal_code' => 100134,
            'phone' => '07037796307',
            'email' => 'adultswimmer@swimmingclubapp.com',
            'email_verified_at' => now(),
            'date_of_birth' => strtotime(date('Y-m-d')),
            'password' => bcrypt('password'),
            'gender' => 'male',
        ]);

        $user3->assignRole('adult_swimmer');


        $user4 = User::create([
            'username' => 'NonAdult',
            'firstname' => 'Non',
            'lastname' => 'Swimmer',
            'address' => 'United Kingdom',
            'postal_code' => 100134,
            'phone' => '07037796307',
            'email' => 'nonadultswimmer@swimmingclubapp.com',
            'email_verified_at' => now(),
            'date_of_birth' => strtotime(date('Y-m-d')),
            'password' => bcrypt('password'),
            'gender' => 'male',
        ]);

        $user4->assignRole('non_adult_swimmer');
    }
}
