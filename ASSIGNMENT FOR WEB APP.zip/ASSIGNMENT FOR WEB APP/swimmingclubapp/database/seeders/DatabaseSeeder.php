<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //seed the super admin to database
        $this->call([
            RoleSeeder::class,
            SuperAdminSeeder::class
        ]);
    }
}
