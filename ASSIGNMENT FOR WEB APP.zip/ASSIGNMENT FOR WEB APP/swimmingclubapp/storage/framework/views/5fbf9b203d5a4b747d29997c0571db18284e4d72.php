<?php if(session()->has('success')): ?>
    <div class="alert">
        <p style="color:white"><?php echo e(session()->get('success')); ?></p>
    </div>
<?php elseif(session()->has('error')): ?>
    <div class="alert-error">
        <p style="color:white"><?php echo e(session()->get('error')); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\adefa\OneDrive\Documents\WEB ASSIGNMENT\swimmingclubapp\resources\views/layouts/message.blade.php ENDPATH**/ ?>