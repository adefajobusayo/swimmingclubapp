<div style="margin-left:10px!important;margin-right:10px!important" class="min-h-screen flex flex-col pt-6 sm:pt-0 bg-gray-100">
    <div style="display: flex; justify-content:space-between;">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\Users\adefa\OneDrive\Documents\WEB ASSIGNMENT\swimmingclubapp\resources\views/components/card.blade.php ENDPATH**/ ?>