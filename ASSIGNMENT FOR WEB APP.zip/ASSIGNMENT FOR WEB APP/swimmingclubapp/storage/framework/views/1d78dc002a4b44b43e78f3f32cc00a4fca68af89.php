<?php $__env->startComponent('mail::message'); ?>

<h3>Welcome <?php echo e($firstname); ?> <?php echo e($lastname); ?></h3>
<h3>Your Login Details: Email - <?php echo e($email); ?>, Reset Your Password!</h3>

Cheers,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\adefa\OneDrive\Documents\WEB ASSIGNMENT\swimmingclubapp\resources\views/emails/admin.blade.php ENDPATH**/ ?>