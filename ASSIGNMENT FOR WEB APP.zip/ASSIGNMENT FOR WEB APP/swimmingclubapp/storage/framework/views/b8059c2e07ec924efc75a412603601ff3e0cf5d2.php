<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coach')): ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <h1 class="text-center" style="font-size: large;">Non Adult Swimmers</h1>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">


                    <table class="table-fixed" style="width: 100%;">
                        <thead>
                            <tr>
                            <th>Name</th>
                            <th>Lastname</th>
                            <th>Gender</th>
                            <th>Date Of Birth</th>
                            <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $nonadultswimmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $swimmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($swimmer->firstname); ?></td>
                                <td class="text-center"><?php echo e($swimmer->lastname); ?></td>
                                <td class="text-center"><?php echo e(ucfirst($swimmer->gender)); ?></td>
                                <td class="text-center"><?php echo e(Date('Y-m-d', $swimmer->date_of_birth)); ?></td>
                                <td class="text-center"><a href="/coach/viewnonadultperformancedata/<?php echo e($swimmer->id); ?>" class="bg-blue-500" role="button">View Performance Data</a></td>

                                <!-- <form method="post" action="/coach/movetoadultsquad">
                                    <?php echo csrf_field(); ?>
                                    <td class="text-center">
                                        <button type="submit" style="background-color: green;padding: 5px;border-radius: 5px;color:white" name="movetoadult" value="<?php echo e($swimmer->id); ?>">View Performance Data</button>
                                    </td>
                                </form> -->
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\adefa\OneDrive\Documents\WEB ASSIGNMENT\swimmingclubapp\resources\views/coach/nonadultswimmers.blade.php ENDPATH**/ ?>