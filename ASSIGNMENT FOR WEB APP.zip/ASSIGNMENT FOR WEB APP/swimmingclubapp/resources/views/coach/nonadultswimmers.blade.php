@can('coach')
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <h1 class="text-center" style="font-size: large;">Non Adult Swimmers</h1>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">


                    <table class="table-fixed" style="width: 100%;">
                        <thead>
                            <tr>
                            <th>Name</th>
                            <th>Lastname</th>
                            <th>Gender</th>
                            <th>Date Of Birth</th>
                            <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($nonadultswimmers as $swimmer)
                            <tr>
                                <td class="text-center">{{$swimmer->firstname}}</td>
                                <td class="text-center">{{$swimmer->lastname}}</td>
                                <td class="text-center">{{ucfirst($swimmer->gender)}}</td>
                                <td class="text-center">{{Date('Y-m-d', $swimmer->date_of_birth)}}</td>
                                <td class="text-center"><a href="/coach/viewnonadultperformancedata/{{$swimmer->id}}" class="bg-blue-500" role="button">View Performance Data</a></td>

                                <!-- <form method="post" action="/coach/movetoadultsquad">
                                    @csrf
                                    <td class="text-center">
                                        <button type="submit" style="background-color: green;padding: 5px;border-radius: 5px;color:white" name="movetoadult" value="{{$swimmer->id}}">View Performance Data</button>
                                    </td>
                                </form> -->
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>
@endcan
