<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

<div style="display: block;">

    <x-card>
        <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
             <x-auth-validation-errors class="mb-4" :errors="$errors" />
            <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
                {{ __('Add Training Performance Data') }}
            </h2>

             <form method="POST" action="{{ route('training-performance') }}">
                @csrf

            <!-- Email Address -->
            <div class="mt-4">
                <x-label for="t_data" :value="__('Training Data')" />

                <input value="{{$id}}" id="position" name="id" class="block mt-1 w-full" type="hidden"  required />
                <input value="" id="position" name="details" class="block mt-1 w-full" type="text"  required autofocus />

            </div>

            <div class="mt-4">
                <x-label for="swimmers" :value="__('Additional Data')" />

                <textarea name="more_details" class="block mt-1 w-full"></textarea>


            </div>



            <div class="flex items-center justify-end mt-4">
                <x-button class="ml-3">
                    {{ __('Submit') }}
                </x-button>
            </div>
        </form>




        </div>
       <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg" style="margin-top:50px!important">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            {{ __('View Training Data') }}
        </h2>

        <div class="mt-3">
             @if(isset($data))

            <ul>
                 @foreach($data as $data)
                <li>{{$data->details}}</li>
                <li>{{$data->more_details}}</li>
                 @endforeach
            </ul>
            @endif

        </div>
       </div>


    </x-card>


</div>




</x-app-layout>
