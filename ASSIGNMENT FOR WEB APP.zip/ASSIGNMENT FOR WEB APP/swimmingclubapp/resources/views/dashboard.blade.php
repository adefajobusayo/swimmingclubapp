<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                @can('coach')
                <div class="p-6 bg-white border-b border-gray-200">
                    <h1 class="text-center">Squad Details</h1>

                    <!-- @if(!empty($swimmers)) -->
                    <table class="table-fixed" style="width: 100%;">
                        <thead>
                            <tr>
                            <th>Name</th>
                            <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td class="text-center">Adult</td>
                                <td class="text-center"><a href="/coach/editadultsquaddetails" class="bg-blue-500" role="button">Edit</a></td>
                            </tr>
                            <tr>
                                <td class="text-center">Non Adult</td>
                                <td class="text-center"><a href="/coach/editnonadultsquaddetails" class="bg-blue-500" role="button">Edit</a></td>
                            </tr>

                        </tbody>
                    </table>

                    <!-- @else
                    <p class="text-center text-red-500">No Records Found!</p>
                    @endif -->

                </div>
                @endcan
            </div>
        </div>
    </div>
</x-app-layout>
