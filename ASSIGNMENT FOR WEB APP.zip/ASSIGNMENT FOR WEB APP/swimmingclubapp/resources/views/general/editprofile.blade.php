<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>
    <x-auth-card>
        <x-auth-validation-errors class="mb-4" :errors="$errors" />
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            {{ __('Edit Profile') }}
        </h2>
        @foreach($userdetails as $details)
        <form method="post" action="{{route('editprofile')}}">
            @csrf
            <!-- Name -->
            <div>
                <x-label for="firstname" :value="__('Firstname')" />

                <input id="firstname" class="block mt-1 w-full" type="text" name="firstname" value="{{$details->firstname}}" required autofocus />
            </div>


            <div class="mt-4">
                <x-label for="lastname" :value="__('Lastname')" />

                <input id="lastname" class="block mt-1 w-full" type="text" name="lastname" value="{{$details->lastname}}" required autofocus />
            </div>

            <!-- Email Address -->
            <div class="mt-4">
                <x-label for="username" :value="__('Username')" />

                <input id="username" class="block mt-1 w-full" type="text" name="username" value="{{$details->username}}" required />
            </div>

            <div class="mt-4">
                <x-label for="date_of_birth" :value="__('Date Of Birth')" />

                <input id="date_of_birth" class="block mt-1 w-full" type="date" name="date_of_birth" value="{{date('Y-m-d', $details->date_of_birth)}}" required />
            </div>

            <div class="mt-4">
                <x-label for="phone" :value="__('Phone')" />

                <input id="phone" class="block mt-1 w-full" type="text" name="phone" value="{{$details->phone}}" required />
            </div>

            <div class="mt-4">
                <x-label for="postal code" :value="__('Postal Code')" />

                <input id="postal_code" class="block mt-1 w-full" type="text" name="postal_code" value="{{$details->postal_code}}" required />
            </div>

            <div class="mt-4">
                <x-label for="address" :value="__('Address')" />

                <input id="address" class="block mt-1 w-full" type="text" name="address" value="{{$details->address}}" required />
            </div>

            <!-- <div class="mt-4">
                <x-label for="gender" :value="__('Gender')" />

                <select id="gender" style="border-radius: 5px;" class="block mt-1 w-full" type="gender" name="gender" value="{{$details->gender}}" required >
                    <option>123</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>
            </div> -->

            <!-- Password -->


            <div class="flex items-center justify-end mt-4">

                <x-button class="ml-4">
                    {{ __('Submit') }}
                </x-button>
            </div>
    </form>
    @endforeach

    </x-auth-card>

</x-app-layout>
