<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

<div style="display: block;">

    <x-card>
        <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
             <x-auth-validation-errors class="mb-4" :errors="$errors" />
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            {{ __('Race Performance Data') }}
        </h2>

        <table class="table-fixed" style="width: 100%;">
            <thead>
                <tr>
                <th>Race</th>
                <th>Position</th>
                </tr>
            </thead>

            <tbody>
                @foreach($racedata as $race)
                <tr>
                    <td class="text-center">{{$race->race_title}}</td>

                    <td class="text-center">{{ucwords($race->position)}}</td>
                </tr>
                @endforeach
            </tbody>
            </table>





    </x-card>


</div>




</x-app-layout>
