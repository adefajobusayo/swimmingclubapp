@component('mail::message')

<h3>Welcome {{$firstname}} {{$lastname}}</h3>
<h3>Your Login Details: Email - {{$email}}, Reset Your Password!</h3>

Cheers,<br>
{{ config('app.name') }}
@endcomponent
