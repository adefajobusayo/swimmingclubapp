@if(session()->has('success'))
    <div class="alert">
        <p style="color:white">{{session()->get('success')}}</p>
    </div>
@elseif(session()->has('error'))
    <div class="alert-error">
        <p style="color:white">{{session()->get('error')}}</p>
    </div>
@endif
