<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>
    <x-auth-card>
        <x-auth-validation-errors class="mb-4" :errors="$errors" />
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            {{ __('Assign Swimmers To Race') }}
        </h2>


        <form method="POST" action="{{ route('assign-race') }}">
            @csrf

            <!-- Email Address -->
            <div>
                <x-label for="race_title" :value="__('Race Title')" />

                <select id="race" style="border-radius: 5px;" class="block mt-1 w-full" type="race" name="raceid" required >
                    @if(isset($races))
                    @foreach($races as $race)
                    <option value="{{$race->id}}">{{$race->race_title}}</option>
                    @endforeach
                    @endif
                </select>
            </div>

            <div class="mt-4">
                <x-label for="swimmers" :value="__('Add Swimmer')" />

                <select id="swimmers" style="border-radius: 5px;" class="block mt-1 w-full" type="swimmers" name="swimmers" required >
                    @if(isset($swimmers))
                    @foreach($swimmers as $swimmer)
                    <option value="{{$swimmer->id}}">{{$swimmer->firstname}} {{$swimmer->lastname}}</option>
                    @endforeach
                    @endif
                </select>
            </div>

            <div class="flex items-center justify-end mt-4">
                <x-button class="ml-3">
                    {{ __('Submit') }}
                </x-button>
            </div>
        </form>


    </x-auth-card>

</x-app-layout>
