<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

<div style="display: block;">

    <x-card>
        <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
             <x-auth-validation-errors class="mb-4" :errors="$errors" />
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            {{ __('Assign Position') }}
        </h2>


        <form method="POST" action="{{ route('set-position') }}">
            @csrf

            <!-- Email Address -->
            <div>
                <x-label for="race_title" :value="__('Race Title')" />

                <input value="{{$race[0]->race_title}}" id="position" class="block mt-1 w-full" type="text"  required autofocus />
                <input value="{{$race[0]->id}}" id="position" class="block mt-1 w-full" type="hidden" name="raceid"  required autofocus />


            </div>

            <div class="mt-4">
                <x-label for="swimmers" :value="__('Select Swimmer')" />

                <select id="swimmers" style="border-radius: 5px;" class="block mt-1 w-full" type="swimmer" name="swimmer" required >
                    @if(isset($swimmers))
                    <option value="" selected disabled>Select Swimmer</option>
                    @foreach($swimmers as $swimmer)
                    <option value="{{$swimmer->id}}">{{$swimmer->firstname}} {{$swimmer->lastname}}</option>
                    @endforeach
                    @endif
                </select>


            </div>

            <div class="mt-4">
                <x-label for="position" :value="__('Position')" />

                <x-input id="position" class="block mt-1 w-full" type="text" name="position"  required autofocus />
            </div>

            <div class="flex items-center justify-end mt-4">
                <x-button class="ml-3">
                    {{ __('Submit') }}
                </x-button>
            </div>
        </form>

        </div>
       <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg" style="margin-top:50px!important">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            {{ __('Race Details') }}
        </h2>

        <div class="">
            <table class="table-fixed" style="width: 100%;">
            <thead>
                <tr>
                <th>Swimmer</th>
                <th>Position</th>
                </tr>
            </thead>

            <tbody>

                @foreach($racedata as $race)
                <tr>
                    <td class="text-center">{{ucwords($race->firstname)}} {{ucwords($race->lastname)}}</td>

                    <td class="text-center">{{ucwords($race->position)}}</td>
                </tr>
                @endforeach


            </tbody>
            </table>
        </div>

       </div>


    </x-card>


</div>




</x-app-layout>
