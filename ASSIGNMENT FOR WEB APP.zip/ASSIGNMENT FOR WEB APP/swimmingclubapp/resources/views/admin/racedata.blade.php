<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>
    <x-auth-card>
        <x-auth-validation-errors class="mb-4" :errors="$errors" />
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            {{ __('Create Race') }}
        </h2>


        <form method="POST" action="{{ route('create-race') }}">
            @csrf

            <!-- Email Address -->
            <div>
                <x-label for="race_title" :value="__('Race Title')" />

                <x-input id="race_title" class="block mt-1 w-full" type="text" name="race_title"  required autofocus />
            </div>

            <div class="flex items-center justify-end mt-4">

                <x-button class="ml-3">
                    {{ __('Submit') }}
                </x-button>
            </div>
        </form>


    </x-auth-card>

    <div style="margin-top: -350px!important;margin-left:20px;margin-right:20px" class="min-h-screen flex flex-col sm:justify-center items-center sm:pt-0 bg-gray-100">
        <div class="w-full sm:max-w-lg px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
             <table class="table-fixed" style="width: 100%;">
                        <thead>
                            <tr>
                            <th>Race Title</th>
                            <th>View</th>
                            <th>Delete</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($races as $race)
                            <tr>
                                <td class="text-center">{{ucwords($race->race_title)}}</td>

                                <td class="text-center"><a href="/admin/viewracedetails/{{$race->id}}" class="bg-blue-500" role="button">View</a></td>

                                <td class="text-center">
                                    <form method="post" action="{{ route('delete-race')}}">
                                        @csrf
                                        <button type="submit" name="id" value="{{$race->id}}">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
        </div>
    </div>




</x-app-layout>
