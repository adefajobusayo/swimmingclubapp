<?php

use App\Http\Controllers\CoachController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


//super admin routes
Route::middleware(['auth', 'role:super_admin'])->prefix('super-admin')->group(function(){
    Route::get('/register-admin', [SuperAdminController::class, 'index']);
    Route::post('/register-admin', [SuperAdminController::class, 'store'])->name('register-admin');
});

Route::middleware(['auth', 'role:admin'])->prefix('admin')->group(function () {
    Route::get('/race-data', [AdminController::class, 'racedataindex']);
    Route::get('/assign-race', [AdminController::class, 'assignraceindex']);

    Route::get('viewracedetails/{id}',[AdminController::class, 'viewracedetails']);
    Route::post('/create-race', [AdminController::class, 'createrace'])->name('create-race');
    Route::post('/set-position', [AdminController::class, 'setposition'])->name('set-position');
    Route::post('/assign-race', [AdminController::class, 'assignrace'])->name('assign-race');

    Route::post('/delete-race', [AdminController::class, 'deleterace'])->name('delete-race');


    

    //Route::post('/register-admin', [SuperAdminController::class, 'store'])->name('register-admin');

});

//coach
Route::middleware(['auth', 'role:coach'])->prefix('coach')->group(function () {
    Route::get('/editadultsquaddetails', [CoachController::class, 'showadult']);
    Route::get('/editnonadultsquaddetails', [CoachController::class, 'shownonadult']);

    Route::post('/training-performance', [CoachController::class, 'trainingperformance'])->name('training-performance');

    //Route::post('/movetoadultsquad', [CoachController::class, 'movetoadultsquad']);
    Route::get('/viewadultperformancedata/{id}', [CoachController::class, 'viewadultperformancedata']);

    Route::get('/viewnonadultperformancedata/{id}', [CoachController::class, 'viewnonadultperformancedata']);
});

Route::middleware(['auth', 'role:parent|adult_swimmer|coach'])->prefix('general')->group(function(){
    Route::get('editprofile', [ProfileController::class, 'index']);
    Route::post('editprofile', [ProfileController::class, 'edit'])->name('editprofile');
    //Route::get('racedata', [ProfileController::class, 'racedataindex']);

});

Route::middleware(['auth', 'role:parent|adult_swimmer|non_adult_swimmer'])->prefix('general')->group(function () {
    Route::get('racedata', [ProfileController::class, 'racedataindex']);
});





Route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';
