$.(document).ready(function () {
    $(".alert").fadeIn(400).delay(3000).fadeOut(600);
});
$(document).ready(function () {
    $(".alert-error").fadeIn(400).delay(3000).fadeOut(600);
});
