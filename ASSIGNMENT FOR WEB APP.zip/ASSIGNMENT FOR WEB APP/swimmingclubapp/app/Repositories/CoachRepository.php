<?php

namespace App\Repositories;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use JasonGuru\LaravelMakeRepository\Repository\BaseRepository;
//use Your Model

/**
 * Class CoachRepository.
 */
class CoachRepository
{
    /**
     * @return string
     *  Return the model
     */
    public function model()
    {
        //return YourModel::class;
    }

    public function showadult()
    {
        return User::role('adult_swimmer')->get();
    }

    public function shownonadult()
    {
        return User::role('non_adult_swimmer')->get();
    }

    public function movetoadultsquad($id){
        $user = User::where('id',$id)->get();
        $user->assignRole('adult_swimmer');
        return true;
    }

    public function gettrainingperformancedata($id){
        return DB::table('training_performance')->where('swimmerid',$id)->get();
    }

    public function trainingperformance($data){
        return DB::table('training_performance')->insert(
            [
                'details' => $data['details'],
                'more_details' => $data['more_details'],
                'swimmerid' => $data['swimmerid'],
                'coachid' => $data['coachid'],
                'created_at' => now(),
                'updated_at' => now()
            ]
        );

    }
}
