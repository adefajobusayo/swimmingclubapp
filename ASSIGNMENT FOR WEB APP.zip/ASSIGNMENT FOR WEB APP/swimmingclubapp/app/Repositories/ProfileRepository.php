<?php

namespace App\Repositories;

use JasonGuru\LaravelMakeRepository\Repository\BaseRepository;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

//use Your Model

/**
 * Class ProfileRepository.
 */
class ProfileRepository
{
    /**
     * @return string
     *  Return the model
     */


    public function show(){
        return User::where('id', Auth::user()->id)->get();
    }

    public function edit($data){
        return User::where('id', Auth::user()->id)->update([
            'username' => $data['username'],
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'address' => $data['address'],
            'postal_code' => $data['postal_code'],
            'phone' => $data['phone'],
            'date_of_birth' => strtotime($data['date_of_birth'])
        ]);
    }

    public function getracedata($id){
        return DB::table('race_data')->where('race_data.swimmerid', $id)->join('race', 'race.id', '=', 'race_data.raceid')->get();
    }
}
