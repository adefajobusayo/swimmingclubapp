<?php

namespace App\Repositories;

use App\Models\User;

use JasonGuru\LaravelMakeRepository\Repository\BaseRepository;
//use Your Model

/**
 * Class DashboardRepository.
 */
class DashboardRepository
{
    /**
     * @return string
     *  Return the model
     */
    public function model()
    {
        //return YourModel::class;
    }

    public function show(){
        //return User::role(['adult_swimmer', 'non_adult_swimmer'])->get();

        return User::role(['admin', 'super_admin'])->get();
    }
}
