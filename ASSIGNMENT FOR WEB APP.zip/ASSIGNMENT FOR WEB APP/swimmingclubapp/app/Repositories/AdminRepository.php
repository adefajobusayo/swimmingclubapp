<?php

namespace App\Repositories;

use Illuminate\Support\Facades\DB;
use App\Models\User;
use JasonGuru\LaravelMakeRepository\Repository\BaseRepository;
//use Your Model

/**
 * Class AdminRepository.
 */
class AdminRepository
{
    /**
     * @return string
     *  Return the model
     */
    public function deleterace($id)
    {
        $del = DB::table('race')
                ->where('id', $id)->delete();

        if($del){
            return DB::table('race_data')
                    ->where('raceid', $id)->delete();
        }

    }

    public function getraceswimmers()
    {
        return User::role(['non_adult_swimmer', 'adult_swimmer'])->paginate(20);
    }

    public function getswimmers(){
        return User::role(['non_adult_swimmer','adult_swimmer'])->get();
    }

    public function getraces()
    {
        return DB::table('race')->get();
    }

    public function createrace($data){
        return DB::table('race')->insert([
            'race_title' => ucwords($data['race_title'])
        ]);
    }

    public function createracedata($data){
        $check = DB::table('race_data')
                    ->where('raceid', $data['raceid'])
                    ->where('swimmerid', $data['swimmers'])
                    ->get();

        if(is_null($check->first()) || empty($check->first())){
            return DB::table('race_data')->insert([
                'raceid' => $data['raceid'],
                'swimmerid' => $data['swimmers'],
                'created_at' => now(),
                'updated_at' => now()
            ]);
        }

        return false;
    }


    public function getRaceDetails($id){
        return DB::table('race_data')->where('race_data.raceid', $id)
                ->join('users', 'users.id', '=', 'race_data.swimmerid')
                ->get();

        //  ->where('race_data.raceid', $id)
        //             ->join('users', 'users.id', '=', 'race_data.swimmerid')
        //             ->get();
    }

    public function setposition($data){
        return DB::table('race_data')
        ->where('raceid', $data['raceid'])
        ->where('swimmerid', $data['swimmer'])
        ->update([
            'position' => $data['position'],
            'updated_at' => now()
        ]);
    }
}
