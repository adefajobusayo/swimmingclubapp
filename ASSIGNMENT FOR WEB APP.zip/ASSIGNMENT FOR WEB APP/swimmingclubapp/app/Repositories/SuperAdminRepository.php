<?php

namespace App\Repositories;

use App\Events\SendAdminMail;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Auth\Events\Registered;

//use JasonGuru\LaravelMakeRepository\Repository\BaseRepository;
//use Your Model

/**
 * Class SuperAdminRepository.
 */
class SuperAdminRepository
{
    /**
     * @return string
     *  Return the model
     */
    public function model()
    {
        //return YourModel::class;
    }



    public function store($data){
        $user = User::create([
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'email' => $data['email'],
            'date_of_birth' => strtotime($data['date_of_birth']),
            'gender' => $data['gender'],
            //'password' => Hash::make($this->generateRandomPassword())
        ]);

        //$user->passwordtosend = $this->generateRandomPassword();

        event(new SendAdminMail($user));
        event(new Registered($user));

        $user->assignRole('admin');
        return $user;
    }
}
