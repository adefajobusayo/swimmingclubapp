<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        Gate::define('admin', function ($user) {
            return $user->hasRole('admin');
        });

        Gate::define('super_admin', function ($user) {
            return $user->hasRole('super_admin');
        });

        Gate::define('coach', function ($user) {
            return $user->hasRole('coach');
        });

        Gate::define('adult_swimmer', function ($user) {
            return $user->hasRole('adult_swimmer');
        });

        Gate::define('non_adult_swimmer', function ($user) {
            return $user->hasRole('non_adult_swimmer');
        });

        Gate::define('parent', function ($user) {
            return $user->hasRole('parent');
        });
    }
}
