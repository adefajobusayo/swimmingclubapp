<?php

namespace App\Http\Controllers;

use App\Repositories\CoachRepository;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CoachController extends Controller
{
    protected $coach;
    public function __construct(CoachRepository $coach)
    {
        $this->coach = $coach;
    }

    public function showadult(){
        $adultswimmers = $this->coach->showadult();
        return view('coach.adultswimmers', compact('adultswimmers'));
    }

    public function shownonadult(){
        $nonadultswimmers = $this->coach->shownonadult();
        return view('coach.nonadultswimmers', compact('nonadultswimmers'));
    }

    public function movetoadultsquad(Request $request)
    {
        try {
            $id = $request->movetoadult;
            $this->coach->movetoadultsquad($id);
            return back()->with('success', 'Squad member moved');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withInput()->withErrors($e->getMessage());
        }
    }

    public function viewadultperformancedata($id){
        // print_r($id);
        // exit;
        $data = $this->coach->gettrainingperformancedata($id);
        return view('coach.trainingdata', compact('id', 'data'));
    }

    public function viewnonadultperformancedata($id)
    {
        // print_r($id);
        // exit;
        $data = $this->coach->gettrainingperformancedata($id);
        return view('coach.trainingdata', compact('id', 'data'));
    }

    public function trainingperformance(Request $request){

        try {
            $request->validate([
                'id' => 'required',
                'details' => 'required',
                'more_details' => 'required'
            ]);

            $data = [
                'details' => $request->details,
                'more_details' => $request->more_details,
                'swimmerid' => $request->id,
                'coachid' => Auth::user()->id
            ];


            $this->coach->trainingperformance($data);
            return back()->with('success', 'Training performance added');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withInput()->withErrors($e->getMessage());
        }
    }


}
