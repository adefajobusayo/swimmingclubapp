<?php

namespace App\Http\Controllers;

use App\Repositories\ProfileRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    //
    protected $profileRepository;

    public function __construct(ProfileRepository $profileRepo)
    {
        $this->profileRepository = $profileRepo;
    }

    public function index(){
        $userdetails = $this->profileRepository->show();
        return view('general.editprofile', compact('userdetails'));
    }

    public function edit(Request $request){
        $data = $request->validate([
            'username' => ['required','string'],
            'firstname' => ['required'],
            'lastname' => ['required'],
            'date_of_birth' => ['required'],
            'address' => ['required', 'string'],
            'postal_code' => ['required', 'string'],
            'phone' => ['required', 'string'],
        ]);
        $update = $this->profileRepository->edit($data);
        if($update){
            return back()->with('success', 'profile updated');
        }
        return back()->withErrors('error', 'Profile Update Failed');
    }

    public function racedataindex(){
        $id = Auth::user()->id;
        $racedata = $this->profileRepository->getracedata($id);

        // print_r($racedata);
        // exit;
        return view('general.racedata', compact('racedata'));
    }
}
