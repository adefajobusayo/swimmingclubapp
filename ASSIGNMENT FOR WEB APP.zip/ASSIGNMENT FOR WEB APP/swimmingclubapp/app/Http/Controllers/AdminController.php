<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\AdminRepository;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    protected $adminRepo;

    public function __construct(AdminRepository $adminRepository)
    {
        $this->adminRepo = $adminRepository;
    }

    public function racedataindex(){
        $races = $this->adminRepo->getraces();
        return view('admin/racedata', compact('races'));
    }

    public function createrace(Request $request){
        try {
            $data = $request->validate([
            'race_title' => 'required',
            ]);
            $this->adminRepo->createrace($data);
            return back()->with('success', 'Race Created');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withErrors($e->getMessage());
        }

    }

    public function assignraceindex(){
        $races = $this->adminRepo->getraces();
        $swimmers = $this->adminRepo->getswimmers();
        return view('admin/assignswimmers', compact(['swimmers', 'races']));

    }

    public function assignrace(Request $request){
        try {
            $data = $request->validate([
                'raceid' => 'required',
                'swimmers' => 'required'
            ]);
            $success = $this->adminRepo->createracedata($data);
            if($success == true){
                return back()->with('success', 'Swimmer Assigned');
            }else{
                return back()->with('error', 'Swimmer Cannot Be Assigned Again');
            }

        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withErrors($e->getMessage());
        }

    }

    public function viewracedetails($id){

        $race = DB::table('race')->where('id', $id)->get(['id', 'race_title']);

        $swimmers = DB::table('race_data')
                    ->where('race_data.raceid', $id)
                    ->join('users', 'users.id', '=', 'race_data.swimmerid')
                    ->get();

        $racedata = $this->adminRepo->getRaceDetails($id);
        return view('admin/racedetails', compact('racedata', 'race', 'swimmers'));
    }


    public function setposition(Request $request){

        try {
            $data = $request->validate([
                'position' => 'required',
                'swimmer' => 'required',
                'raceid' => 'required|string'
            ]);

            $this->adminRepo->setposition($data);
            return back()->with('success', 'Position Set');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withErrors($e->getMessage());
        }



    }

    public function deleterace(Request $request){

        try {
            $this->adminRepo->deleterace($request->id);
            return back()->with('success', 'Race Deleted');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return back()->withErrors($e->getMessage());
        }
    }
}
