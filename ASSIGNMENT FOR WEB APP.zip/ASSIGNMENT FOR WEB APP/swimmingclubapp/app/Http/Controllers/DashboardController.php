<?php

namespace App\Http\Controllers;

use App\Repositories\DashboardRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    //
    protected $dashboard;

    public function __construct(DashboardRepository $dashboardrepo){
        $this->dashboard = $dashboardrepo;
    }

    public function index(){
        $swimmers = $this->dashboard->show();
        return view('dashboard', compact('swimmers'));
    }
}
