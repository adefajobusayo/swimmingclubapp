<?php

namespace App\Http\Controllers;

use App\Repositories\SuperAdminRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class SuperAdminController extends Controller
{
    //
    protected $superAdminRepo;

    public function __construct(SuperAdminRepository $superAdminRepository)
    {
        $this->superAdminRepo = $superAdminRepository;
    }


    public function index(){
        return view('superadmin/registeradmin');
    }

    private function generateRandomPassword()
    {
        return Str::random(8);
    }


    public function store(Request $request)
    {
        $data = $request->validate([
            'firstname' => 'required|string|max:30',
            'lastname' => 'required|string|max:30',
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'date_of_birth' => 'required',
            'gender' => 'required'
        ]);

        try{
            $this->superAdminRepo->store($data);
            return back()->with('success', 'Registration Successful');
        }catch(\Exception $e){
            Log::error($e->getMessage());
            return back()->withInput()->withErrors($e->getMessage());
        }
        
    }
}
