<?php

namespace App\Listeners;

use App\Events\SendAdminMail;
use App\Mail\AdminRegistrationMail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\User;
use Illuminate\Support\Facades\Mail;

class SendAdminMailFired
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\SendAdminMail  $event
     * @return void
     */
    public function handle(SendAdminMail $event)
    {
        Mail::to($event->user->email)->send(
            new AdminRegistrationMail($event->user)
        );
    }

}
